# WiFi Analyzer+ — sestavení APK přes GitHub Actions

Tento ZIP je připravený pro nahrání do GitHub repozitáře. GitHub Actions se pokusí sestavit Android APK automaticky.

## Jak získat APK z telefonu

1. Přihlas se na https://github.com a vytvoř nový **public nebo private repository** (např. `WifiAnalyzerPlus`).
2. Rozbal tento ZIP. Otevři složku `WifiAnalyzerFlipper` — **obsah této složky** (zejména `app`, `build.gradle`, `settings.gradle`, `.github`) nahraj do kořene repozitáře. Nenahrávej obalovou složku `WifiAnalyzerFlipper` jako další vnořenou složku.
3. Na stránce repozitáře otevři **Actions** a vyber **Build Android APK**.
4. Klikni na **Run workflow** a potvrď zeleným tlačítkem **Run workflow**. Při prvním pushnutí do `main`/`master` se workflow spustí i samo.
5. Po dokončení otevři běh workflow, sjeď na **Artifacts** a stáhni `WiFiAnalyzerPlus-debug-apk`.
6. Rozbal stažený ZIP artefaktu. Uvnitř bude `app-debug.apk`, který můžeš přenést do telefonu a nainstalovat.

## Když se sestavení nepovede

Otevři neúspěšný běh v Actions a zkopíruj posledních přibližně 30–50 řádků chybového logu. Build workflow pomůže odhalit chyby, ale samo o sobě nezaručuje, že současný zdrojový kód projde kompilací.

## Důležité

- Workflow sestavuje **debug APK**, nikoli podepsanou produkční verzi pro Google Play.
- Tento projekt používá Android SDK 35 a Java 17.
- Nahrání souborů do tvého GitHub účtu vyžaduje přihlášení a tvůj vlastní krok. Z tohoto chatu nemám přístup k tvému účtu, takže jsem připravil projekt a automatické sestavení, ale nemohu sám vytvořit repozitář v tvém účtu.
