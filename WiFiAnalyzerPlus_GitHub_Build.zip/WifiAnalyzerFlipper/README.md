# WiFi Analyzer+ PRO — v4.2 BLE Compass

Android Studio project in Java. `minSdk 26`, `compileSdk 35`, Android Gradle Plugin 8.7.3.

## Functions
- Wi-Fi scan results and 2.4 GHz channel graph.
- BLE scanner for named and nameless advertisements, sorted by smoothed RSSI.
- 15-second BLE scan with stop button, periodic UI refresh, selection/highlight of one device, and clear-results control.
- Approximate RSSI-based distance estimate (not a real range measurement).
- Phone compass indicating magnetic north and heading.
- Network diagnostics, USB device listing, NFC NDEF reader/writer, and IR transmitter UI.

## BLE limitations
The app can detect only BLE devices that actively transmit advertising packets. “Nameless” means the advertisement has no usable name; it does not mean the device is invisible or that scanning can reveal devices which do not transmit. RSSI distance estimates are approximate and affected by walls, body position, antenna design, transmit power and interference. The compass indicates magnetic north and phone heading; a normal phone cannot determine the actual bearing to a BLE transmitter from RSSI alone. True BLE direction finding requires compatible direction-finding hardware and target support.

## Permissions
Allow Nearby devices / Bluetooth scan and, if Android requests it, location permission. Permission names and requirements depend on Android version. If scanning returns no results, enable Bluetooth, grant permissions and try again near an actively advertising BLE device.

## Build APK
1. Open the `WifiAnalyzerFlipper` folder in Android Studio.
2. Let Gradle sync complete (Android Gradle Plugin 8.7.3 requires a compatible recent Android Studio/Gradle setup).
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This environment has no Android SDK / Gradle installation, so the project could not be compiled or tested on a physical phone here. Treat the generated project as source code until you build and verify it in Android Studio.
